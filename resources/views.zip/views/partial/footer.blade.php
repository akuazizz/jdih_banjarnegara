@include('partial/socialmedia')
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<a href="https://api.whatsapp.com/send?phone=6281226069559&text=Selamat%20Pagi%20Pak,%20Saya%20mau%20tanya%20?"
    class="float" target="_blank">
    <i class="fa fa-whatsapp my-float text-white"></i>
</a>
<div class="footer py-4 d-flex flex-lg-column kt_footer" style="background-color: rgb(0, 0, 0)">
    <div class="container-xxl d-flex flex-column flex-md-row align-items-center justify-content-center">
        <div class="text-white font-karla order-3 order-md-1">
            Hak Cipta 2024©
            Bagian Hukum Pemerintah Kabupaten Banjarnegara
        </div>
    </div>
    <div class="container-xxl d-flex flex-column flex-md-row align-items-center justify-content-center">
        <a href="{{ route('disclaimer') }}">Disclaimer</a>
    </div>
</div>

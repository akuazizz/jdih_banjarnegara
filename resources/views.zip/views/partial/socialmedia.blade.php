<footer class="footer-area footer-eleven">
    <div class="footer-top">
        <div class="container">
            <div class="inner-content">
                <div class="row">

                    <div class="col-lg-4 col-md-6 col-12">
                        <a href="{{ url('') }}">
                            <div class="mb-3 flex">
                                <img src="{{ asset('jdih_banjar_3.png') }}" alt="Logo JDIH" class="bg-contain">
                            </div>
                        </a>
                        <div class="cat-item d-flex">
                            <div class="cat-img mr-4 bg-primary-transparent p-3 brround">
                                <img src="{{ asset('logo_banjarnegara_new.png') }}" class="w-16">
                            </div>
                            <div class="cat-desc text-left">
                                <p class="text-l ml-2 self-center text-white">
                                    <br>{{ GoogleTranslate::trans('Bagian Hukum Pemerintah Kabupaten Banjarnegara', app()->getLocale()) }}
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-6 col-12">

                        <div class="footer-widget f-link">
                            <h5 class="text-white">{{ GoogleTranslate::trans('Social Media', app()->getLocale()) }}</h5>
                            <ul class="p-1em">
                                <!-- <li>
                                    <a href="https://www.youtube.com/channel/UCFFZo4PAotie8YCr49chvqg" target="_blank">
                                        <div class="flex">
                                            <svg class="svg-icon" viewBox="0 0 20 20">
                                                <path fill="none"
                                                    d="M9.426,7.625h0.271c0.596,0,1.079-0.48,1.079-1.073V4.808c0-0.593-0.483-1.073-1.079-1.073H9.426c-0.597,0-1.079,0.48-1.079,1.073v1.745C8.347,7.145,8.83,7.625,9.426,7.625 M9.156,4.741c0-0.222,0.182-0.402,0.404-0.402c0.225,0,0.405,0.18,0.405,0.402V6.62c0,0.222-0.181,0.402-0.405,0.402c-0.223,0-0.404-0.181-0.404-0.402V4.741z M12.126,7.625c0.539,0,1.013-0.47,1.013-0.47v0.403h0.81V3.735h-0.81v2.952c0,0-0.271,0.335-0.54,0.335c-0.271,0-0.271-0.202-0.271-0.202V3.735h-0.81v3.354C11.519,7.089,11.586,7.625,12.126,7.625 M6.254,7.559H7.2v-2.08l1.079-2.952H7.401L6.727,4.473L6.052,2.527H5.107l1.146,2.952V7.559z M11.586,12.003c-0.175,0-0.312,0.104-0.405,0.204v2.706c0.086,0.091,0.213,0.18,0.405,0.18c0.405,0,0.405-0.451,0.405-0.451v-2.188C11.991,12.453,11.924,12.003,11.586,12.003 M14.961,8.463c0,0-2.477-0.129-4.961-0.129c-2.475,0-4.96,0.129-4.96,0.129c-1.119,0-2.025,0.864-2.025,1.93c0,0-0.203,1.252-0.203,2.511c0,1.252,0.203,2.51,0.203,2.51c0,1.066,0.906,1.931,2.025,1.931c0,0,2.438,0.129,4.96,0.129c2.437,0,4.961-0.129,4.961-0.129c1.117,0,2.024-0.864,2.024-1.931c0,0,0.202-1.268,0.202-2.51c0-1.268-0.202-2.511-0.202-2.511C16.985,9.328,16.078,8.463,14.961,8.463 M7.065,10.651H6.052v5.085H5.107v-5.085H4.095V9.814h2.97V10.651z M9.628,15.736h-0.81v-0.386c0,0-0.472,0.45-1.012,0.45c-0.54,0-0.606-0.515-0.606-0.515v-3.991h0.809v3.733c0,0,0,0.193,0.271,0.193c0.27,0,0.54-0.322,0.54-0.322v-3.604h0.81V15.736z M12.801,14.771c0,0,0,1.03-0.742,1.03c-0.455,0-0.73-0.241-0.878-0.429v0.364h-0.876V9.814h0.876v1.92c0.135-0.142,0.464-0.439,0.878-0.439c0.54,0,0.742,0.45,0.742,1.03V14.771z M15.973,12.39v1.287h-1.688v0.965c0,0,0,0.451,0.405,0.451s0.405-0.451,0.405-0.451v-0.45h0.877v0.708c0,0-0.136,0.901-1.215,0.901c-1.08,0-1.282-0.901-1.282-0.901v-2.51c0,0,0-1.095,1.282-1.095S15.973,12.39,15.973,12.39 M14.69,12.003c-0.405,0-0.405,0.45-0.405,0.45v0.579h0.811v-0.579C15.096,12.453,15.096,12.003,14.69,12.003">
                                                </path>
                                            </svg>

                                            <span class="ml-2 text-white">JDIH Provinsi Jawa Tengah</span>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="https://www.facebook.com/jdihprovjateng" target="_blank">
                                        <div class="flex">
                                            <svg class="svg-icon" viewBox="0 0 20 20">
                                                <path fill="none"
                                                    d="M11.344,5.71c0-0.73,0.074-1.122,1.199-1.122h1.502V1.871h-2.404c-2.886,0-3.903,1.36-3.903,3.646v1.765h-1.8V10h1.8v8.128h3.601V10h2.403l0.32-2.718h-2.724L11.344,5.71z">
                                                </path>
                                            </svg>
                                            <span class="ml-2 text-white">JDIH Provinsi Jawa Tengah</span>
                                        </div>
                                    </a>
                                </li> -->
                                <li>
                                    <a href="https://www.tiktok.com/@jdih_banjarnegara" target="_blank">
                                        <div class="flex">
                                        <img src="{{asset('media/tiktok.svg')}}" class="svg-icon"/>
                                            <span class="ml-2 text-white">JDIH Kabupaten Banjarnegara</span>
                                        </div>
                                    </a>
                                </li>
                                
                                <li>
                                    <a href="https://www.instagram.com/jdih_banjarnegara/" target="_blank">
                                        <div class="flex">
                                            <svg class="svg-icon" viewBox="0 0 20 20">
                                                <path fill="none"
                                                    d="M14.52,2.469H5.482c-1.664,0-3.013,1.349-3.013,3.013v9.038c0,1.662,1.349,3.012,3.013,3.012h9.038c1.662,0,3.012-1.35,3.012-3.012V5.482C17.531,3.818,16.182,2.469,14.52,2.469 M13.012,4.729h2.26v2.259h-2.26V4.729z M10,6.988c1.664,0,3.012,1.349,3.012,3.012c0,1.664-1.348,3.013-3.012,3.013c-1.664,0-3.012-1.349-3.012-3.013C6.988,8.336,8.336,6.988,10,6.988 M16.025,14.52c0,0.831-0.676,1.506-1.506,1.506H5.482c-0.831,0-1.507-0.675-1.507-1.506V9.247h1.583C5.516,9.494,5.482,9.743,5.482,10c0,2.497,2.023,4.52,4.518,4.52c2.494,0,4.52-2.022,4.52-4.52c0-0.257-0.035-0.506-0.076-0.753h1.582V14.52z">
                                                </path>
                                            </svg>

                                            <span class="ml-2 text-white">@jdih_banjarnegara</span>
                                        </div>
                                    </a>
                                </li>
                                <!-- <li>
                                    <a href="https://twitter.com/jdihprovjateng" target="_blank">
                                        <div class="flex">
                                            <svg class="svg-icon" viewBox="0 0 20 20">
                                                <path fill="none"
                                                    d="M18.258,3.266c-0.693,0.405-1.46,0.698-2.277,0.857c-0.653-0.686-1.586-1.115-2.618-1.115c-1.98,0-3.586,1.581-3.586,3.53c0,0.276,0.031,0.545,0.092,0.805C6.888,7.195,4.245,5.79,2.476,3.654C2.167,4.176,1.99,4.781,1.99,5.429c0,1.224,0.633,2.305,1.596,2.938C2.999,8.349,2.445,8.19,1.961,7.925C1.96,7.94,1.96,7.954,1.96,7.97c0,1.71,1.237,3.138,2.877,3.462c-0.301,0.08-0.617,0.123-0.945,0.123c-0.23,0-0.456-0.021-0.674-0.062c0.456,1.402,1.781,2.422,3.35,2.451c-1.228,0.947-2.773,1.512-4.454,1.512c-0.291,0-0.575-0.016-0.855-0.049c1.588,1,3.473,1.586,5.498,1.586c6.598,0,10.205-5.379,10.205-10.045c0-0.153-0.003-0.305-0.01-0.456c0.7-0.499,1.308-1.12,1.789-1.827c-0.644,0.28-1.334,0.469-2.06,0.555C17.422,4.782,17.99,4.091,18.258,3.266">
                                                </path>
                                            </svg>
                                            <span class="ml-2 text-white">@jdihprovjateng</span>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="https://play.google.com/store/apps/details?id=com.smt.jdihjatengmobile&pli=1"
                                        target="_blank">
                                        <div class="flex">
                                            <svg width="2em" height="2em" style="color: white" role="img"
                                                viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                <title>Google Play</title>
                                                <path
                                                    d="M22.018 13.298l-3.919 2.218-3.515-3.493 3.543-3.521 3.891 2.202a1.49 1.49 0 0 1 0 2.594zM1.337.924a1.486 1.486 0 0 0-.112.568v21.017c0 .217.045.419.124.6l11.155-11.087L1.337.924zm12.207 10.065l3.258-3.238L3.45.195a1.466 1.466 0 0 0-.946-.179l11.04 10.973zm0 2.067l-11 10.933c.298.036.612-.016.906-.183l13.324-7.54-3.23-3.21z"
                                                    fill="white"></path>
                                            </svg>
                                            <span class="ml-2 text-white">Apps JDIH</span>
                                        </div>
                                    </a>
                                </li> -->
                            </ul>
                        </div>

                    </div>
                    <div class="col-lg-2 col-md-6 col-12">

                        <div class="footer-widget f-link">
                            <h5 class="text-white">{{ GoogleTranslate::trans('Address', app()->getLocale()) }}</h5>
                            <ul class="p-1em">

                                <li>
                                    <a href="javascript:void(0)">
                                        <div class="flex">
                                            <svg class="svg-icon" viewBox="0 0 20 20">
                                                <path fill="none"
                                                    d="M14.584,1.617l-4.625,2.89L5.333,2.195L0.709,4.495v13.888l4.625-2.313l4.625,1.157l4.625-1.734l4.625,1.734
        V3.93L14.584,1.617z M18.053,15.492l-3.469-1.157l-4.625,1.734l-4.625-1.155l-3.468,1.734V5.086l3.468-1.734l4.625,2.312
        l4.625-2.891l3.469,1.734V15.492z M10.248,6.827c-0.16,0-0.29,0.163-0.29,0.363v6.781c0,0.201,0.129,0.363,0.29,0.363
        c0.16,0,0.289-0.162,0.289-0.363V7.19C10.537,6.99,10.408,6.827,10.248,6.827z M5.623,5.093c-0.16,0-0.29,0.163-0.29,0.363v7.938
        c0,0.201,0.129,0.363,0.29,0.363c0.16,0,0.289-0.162,0.289-0.363V5.456C5.912,5.256,5.783,5.093,5.623,5.093z M14.584,12.815
        c0,0.2,0.129,0.363,0.289,0.363s0.289-0.163,0.289-0.363V4.878c0-0.2-0.129-0.364-0.289-0.364s-0.289,0.164-0.289,0.364V12.815z">
                                                </path>
                                            </svg>
                                            <span class="ml-2 text-white">Jl. Ahmad Yani No. 16, Krandegan,
                                                Banjarnegara</span>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)">
                                        <div class="flex">
                                            <span class="ml-2 text-white">Telp. (0286) 591218</span>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)">
                                        <div class="flex">
                                            <span class="ml-2 text-white">Email : jdih@banjarnegarakab.go.id</span>
                                        </div>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="footer-widget newsletter">
                            <h5 class="text-white">{{ GoogleTranslate::trans('Visitor', app()->getLocale()) }}</h5>
                            <table style="color:white;width:50%;padding:5px;">
                                <tr style=" solid;padding:5px;">
                                    <th style=" solid;padding:5px;">Daily</th>
                                    <th style=" solid;padding:5px;text-align:right;"><span
                                            style="background-color:coral;padding:3px;border-radius:10px;">{{ Helper::getVisitor()[0]->daily }}</span>
                                    </th>
                                <tr>
                                <tr style=" solid;padding:5px;">
                                    <th style=" solid;padding:5px;">Weekly</th>
                                    <th style=" solid;padding:5px;text-align:right;"><span
                                            style="background-color:coral;padding:3px;border-radius:10px;">{{ Helper::getVisitor()[0]->weekly }}</span>
                                    </th>
                                <tr>
                                <tr style=" solid;padding:5px;">
                                    <th style=" solid;padding:5px;">Mountly</th>
                                    <th style=" solid;padding:5px;text-align:right;"><span
                                            style="background-color:coral;padding:3px;border-radius:10px;">{{ Helper::getVisitor()[0]->mounty }}</span>
                                    </th>
                                <tr>
                                <tr style=" solid;padding:5px;">
                                    <th style=" solid;padding:5px;">Yearly</th>
                                    <th style=" solid;padding:5px;text-align:right;"><span
                                            style="background-color:coral;padding:3px;border-radius:10px;">{{ Helper::getVisitor()[0]->yearly }}</span>
                                    </th>
                                <tr>
                            </table>
                            <hr>
                            <h5 class="text-white">{{ GoogleTranslate::trans('Survei Kepuasan', app()->getLocale()) }}
                            </h5>
                            <table style=" solid;color:white;width:50%;padding:5px;">
                                <tr style=" solid;padding:5px;">
                                    <th style=" solid;padding:5px;">Sangat Puas</th>
                                    <th style=" solid;padding:5px;text-align:right;"><span
                                            style="background-color:coral;padding:3px;border-radius:10px;">{{ Helper::getSurvei()[0]->sangat_puas }}</span>
                                    </th>
                                <tr>
                                <tr style=" solid;padding:5px;">
                                    <th style=" solid;padding:5px;">Puas</th>
                                    <th style=" solid;padding:5px;text-align:right;"><span
                                            style="background-color:coral;padding:3px;border-radius:10px;">{{ Helper::getSurvei()[0]->puas }}</span>
                                    </th>
                                <tr>
                                <tr style=" solid;padding:5px;">
                                    <th style=" solid;padding:5px;">Kurang Puas</th>
                                    <th style=" solid;padding:5px;text-align:right;"><span
                                            style="background-color:coral;padding:3px;border-radius:10px;">{{ Helper::getSurvei()[0]->kurang_puas }}</span>
                                    </th>
                                <tr>
                                <tr style=" solid;padding:5px;">
                                    <th style=" solid;padding:5px;">Tidak Puas</th>
                                    <th style=" solid;padding:5px;text-align:right;"><span
                                            style="background-color:coral;padding:3px;border-radius:10px;">{{ Helper::getSurvei()[0]->tidak_puas }}</span>
                                    </th>
                                <tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</footer>
<table class="table border" width="100%">
    <tbody>
    <tr>
        <td class="middle mb-10">
            {!! $data[0]->abstrak !!}
        </td>
    </tr>
    </tbody>
</table>
